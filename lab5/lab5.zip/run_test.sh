#!/bin/bash

./compile.sh

./build/lab5 < test/case1.in
